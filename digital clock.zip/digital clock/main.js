function showDate() {
  var d = new Date();
  var dd = d.getDate();
  var mm = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'June',
    'July',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec'
  ];
  var y = d.getFullYear();
  var h = d.getHours();
  var min = d.getMinutes();
  var sec = d.getSeconds();
  var day = [
    'Sunday',
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday'
  ];
  if (dd < 10) {
    dd = '0' + dd;
  }
  if (min < 10) {
    min = '0' + min;
  }
  if (h < 10) {
    h = '0' + h;
  } else if (h > 12) {
    h = h - 12;
    h = '0' + h;
  }
  if (sec < 10) {
    sec = '0' + sec;
  }

  var time = h + ':' + min + ':' + sec;
  var date = dd + ' ' + mm[d.getMonth()] + ' ' + y;

  document.getElementById('dateTime').innerHTML = `${time} <br> ${
    day[d.getDay()]
  } <br>
  ${date}`;
}

setInterval(showDate, 1000);
